"""AI screenshot analysis backend.

Set OPENAI_API_KEY on the server before using. This endpoint uses a vision-capable
model to describe chart structure, but it cannot guarantee the next candle.
No Quotex OTC feed is included.
"""
import base64
import os
from io import BytesIO

from fastapi import FastAPI, File, HTTPException, UploadFile
from openai import OpenAI
from PIL import Image, UnidentifiedImageError

app = FastAPI(title="Quotex AI Analyzer Backend", version="0.2.0")

MAX_IMAGE_BYTES = 12 * 1024 * 1024
MODEL = os.getenv("OPENAI_VISION_MODEL", "gpt-4.1-mini")


@app.get("/health")
def health():
    return {
        "status": "ok",
        "ai_key_configured": bool(os.getenv("OPENAI_API_KEY")),
        "otc_feed_connected": False,
        "note": "Quotex OTC feed is not integrated or verified."
    }


@app.post("/analyze")
async def analyze(file: UploadFile = File(...)):
    if not file.content_type or not file.content_type.startswith("image/"):
        raise HTTPException(status_code=415, detail="Please upload an image file.")
    raw = await file.read()
    if not raw or len(raw) > MAX_IMAGE_BYTES:
        raise HTTPException(status_code=413, detail="Image must be non-empty and under 12 MB.")
    try:
        image = Image.open(BytesIO(raw))
        image.verify()
        image = Image.open(BytesIO(raw)).convert("RGB")
        image.thumbnail((1600, 1600))
        buf = BytesIO()
        image.save(buf, format="JPEG", quality=85)
        image_b64 = base64.b64encode(buf.getvalue()).decode("ascii")
    except (UnidentifiedImageError, OSError):
        raise HTTPException(status_code=400, detail="Image could not be read.")

    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        return {
            "analysis": (
                "ছবি গ্রহণ করা হয়েছে, কিন্তু AI API key সেট করা নেই। "
                "সার্ভারে OPENAI_API_KEY যোগ করার পর AI বিশ্লেষণ চালু হবে। "
                "এখন কোনো UP/DOWN সিগন্যাল তৈরি করা হয়নি।"
            ),
            "ai_connected": False,
            "otc_feed_connected": False
        }

    try:
        client = OpenAI(api_key=api_key)
        response = client.responses.create(
            model=MODEL,
            input=[{
                "role": "user",
                "content": [
                    {
                        "type": "input_text",
                        "text": (
                            "Analyze this trading chart screenshot cautiously. "
                            "Respond in Bengali. Identify visible timeframe and pair only if legible; "
                            "describe trend, visible candle patterns, possible support/resistance, "
                            "and image/data limitations. If the image is unclear, say so. "
                            "You may give a tentative bullish/bearish/unclear scenario, but do not "
                            "claim certainty, do not invent prices, and do not describe a confidence "
                            "score as a calibrated win probability. Clearly say that a screenshot alone "
                            "cannot reliably predict the next candle and that OTC feed authenticity "
                            "cannot be verified from the image."
                        )
                    },
                    {
                        "type": "input_image",
                        "image_url": f"data:image/jpeg;base64,{image_b64}"
                    }
                ]
            }]
        )
        analysis = response.output_text.strip() or "AI returned no readable analysis."
        return {
            "analysis": analysis,
            "ai_connected": True,
            "otc_feed_connected": False,
            "model": MODEL
        }
    except Exception as exc:
        # Avoid exposing secrets or full provider error details to the client.
        raise HTTPException(status_code=502, detail=f"AI provider request failed ({type(exc).__name__}). Check server logs.")
