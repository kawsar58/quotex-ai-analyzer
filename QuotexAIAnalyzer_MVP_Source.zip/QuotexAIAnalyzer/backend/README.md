# AI backend setup

1. Install Python 3.11+.
2. Run `pip install -r requirements.txt`.
3. Set environment variables on the server (do not put the API key in the Android app):
   - `OPENAI_API_KEY` = your own API key
   - optional `OPENAI_VISION_MODEL` = a vision-capable model available to your account
4. Run `uvicorn main:app --host 0.0.0.0 --port 8000`.
5. Check `/health`; `ai_key_configured` should be true.
6. Configure the Android app's backend URL to the server's HTTPS base URL.

The screenshot endpoint calls the OpenAI Responses API with an image input. API access and usage billing must be enabled on your account. Never commit `.env` or publish the key.

## Live mode limitations
The Android starter only asks for MediaProjection permission. It does NOT yet capture frames continuously or analyze them. A foreground service, notification, lifecycle handling, throttling, and frame upload pipeline still need to be implemented and tested. Quotex-specific OTC feed/API access is not integrated or verified.
