package com.kawsar.quotexanalyzer

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Monitor
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Bg = Color(0xFF08111F)
private val Panel = Color(0xFF111D30)
private val Cyan = Color(0xFF55D6E8)
private val Muted = Color(0xFF9AAAC0)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AnalyzerApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AnalyzerApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("analyzer", Context.MODE_PRIVATE) }
    var selectedUri by remember { mutableStateOf<Uri?>(null) }
    var fileName by remember { mutableStateOf("No screenshot selected") }
    var isAnalyzing by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf("Upload a chart screenshot to begin analysis.") }
    var liveStatus by remember { mutableStateOf("Not started") }
    var marketResult by remember { mutableStateOf("No live market analysis yet.") }
    var marketLoading by remember { mutableStateOf(false) }
    var marketSymbol by remember { mutableStateOf("BTCUSDT") }
    var marketInterval by remember { mutableStateOf("1m") }
    var history by remember { mutableStateOf(prefs.getString("history", "") ?: "") }
    var backendUrl by remember { mutableStateOf(prefs.getString("backend_url", "") ?: "") }
    val scope = rememberCoroutineScope()

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        selectedUri = uri
        if (uri != null) fileName = queryDisplayName(context, uri)
    }
    val screenCaptureLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { response ->
        liveStatus = if (response.resultCode == Activity.RESULT_OK && response.data != null)
            "Permission granted — frame processing is not connected yet."
        else "Permission denied"
        result = if (response.resultCode == Activity.RESULT_OK)
            "Screen capture permission granted. This starter does not yet process frames or connect to Quotex data."
        else result
    }

    fun saveHistory(source: String, text: String) {
        val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
        history = ("$stamp | $source | ${text.replace("\n", " ").take(180)}\n" + history).take(5000)
        prefs.edit().putString("history", history).apply()
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, background = Bg, surface = Panel, onBackground = Color.White, onSurface = Color.White)) {
        Scaffold(containerColor = Bg, topBar = {
            TopAppBar(title = {
                Column {
                    Text("QUOTEX AI ANALYZER", fontWeight = FontWeight.Black)
                    Text("Personal research tool • MVP 0.1", style = MaterialTheme.typography.labelSmall, color = Muted)
                }
            }, colors = TopAppBarDefaults.topAppBarColors(containerColor = Bg))
        }) { padding ->
            Column(Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("AI CHART WORKSPACE", color = Cyan, style = MaterialTheme.typography.labelLarge)
                        Text("Screenshot + Live Screen", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        Text("Analyze chart structure, not guaranteed future candles.", color = Muted)
                    }
                }
                Text("1 • SCREENSHOT ANALYZER", color = Cyan, fontWeight = FontWeight.Bold)
                Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(fileName, color = Muted)
                        Button(onClick = { imagePicker.launch("image/*") }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.Image, null); Spacer(Modifier.width(8.dp)); Text("Choose Chart Screenshot")
                        }
                        Button(enabled = selectedUri != null && !isAnalyzing, onClick = {
                            val uri = selectedUri ?: return@Button
                            isAnalyzing = true
                            result = "Preparing screenshot analysis…"
                            scope.launch {
                                val output = withContext(Dispatchers.IO) {
                                    if (backendUrl.isNotBlank()) try { callBackend(context, backendUrl, uri) }
                                    catch (e: Exception) { "Backend request failed: ${e.message}. No signal generated." }
                                    else "Screenshot selected successfully, but AI analysis is not connected yet. Configure a private FastAPI backend. This build will not invent a UP/DOWN signal from an unprocessed image."
                                }
                                result = output
                                saveHistory("Screenshot", output)
                                isAnalyzing = false
                            }
                        }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Bg)) {
                            Icon(Icons.Default.Analytics, null); Spacer(Modifier.width(8.dp)); Text(if (isAnalyzing) "Analyzing…" else "Analyze Screenshot")
                        }
                    }
                }
                Text("2 • LIVE SCREEN ANALYZER", color = Cyan, fontWeight = FontWeight.Bold)
                Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Status: $liveStatus")
                        Text("FREE REAL-MARKET DATA • Binance public API • Crypto spot only", color = Cyan, style = MaterialTheme.typography.labelSmall)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                            listOf("BTCUSDT", "ETHUSDT", "SOLUSDT").forEach { sym ->
                                FilterChip(selected = marketSymbol == sym, onClick = { marketSymbol = sym }, label = { Text(sym) })
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                            listOf("1m", "5m", "15m").forEach { tf ->
                                FilterChip(selected = marketInterval == tf, onClick = { marketInterval = tf }, label = { Text(tf) })
                            }
                        }
                        Button(enabled = !marketLoading, onClick = {
                            marketLoading = true
                            scope.launch {
                                val out = withContext(Dispatchers.IO) {
                                    try { fetchPublicMarketAnalysis(marketSymbol, marketInterval) }
                                    catch (e: Exception) { "Live data request failed: ${e.message}" }
                                }
                                marketResult = out
                                saveHistory("Live $marketSymbol $marketInterval", out)
                                marketLoading = false
                            }
                        }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Bg)) {
                            Icon(Icons.Default.Analytics, null); Spacer(Modifier.width(8.dp))
                            Text(if (marketLoading) "Fetching market data…" else "Analyze Real Market (Free)")
                        }
                        Text(marketResult, color = Color.White)
                        HorizontalDivider(color = Color(0xFF26364B))
                        Text("Android asks permission before screen capture. Permission is only requested here; continuous frame processing is not yet implemented.", color = Muted)
                        Button(onClick = {
                            val manager = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                            screenCaptureLauncher.launch(manager.createScreenCaptureIntent())
                        }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.Monitor, null); Spacer(Modifier.width(8.dp)); Text("Grant Screen Capture Permission")
                        }
                    }
                }
                Text("3 • ANALYSIS RESULT", color = Cyan, fontWeight = FontWeight.Bold)
                Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(result)
                        HorizontalDivider(color = Color(0xFF26364B))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Warning, null, tint = Color(0xFFFFC857)); Spacer(Modifier.width(8.dp))
                            Text("No guaranteed predictions. OTC feed/API access is unverified.", color = Color(0xFFFFD98A), style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
                Text("4 • LOCAL HISTORY", color = Cyan, fontWeight = FontWeight.Bold)
                Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.History, null, tint = Cyan); Spacer(Modifier.width(8.dp)); Text("Recent analysis attempts", fontWeight = FontWeight.Bold)
                        }
                        Text(if (history.isBlank()) "No history yet." else history, color = Muted, style = MaterialTheme.typography.bodySmall)
                        OutlinedButton(onClick = { history = ""; prefs.edit().remove("history").apply() }) { Text("Clear History") }
                        OutlinedTextField(value = backendUrl, onValueChange = {
                            backendUrl = it
                            prefs.edit().putString("backend_url", it).apply()
                        }, label = { Text("Private backend URL (optional)") }, placeholder = { Text("https://your-server.example") },
                            modifier = Modifier.fillMaxWidth(), singleLine = true)
                    }
                }
                Text("Starter source project, not a compiled APK. AI backend and real-time frame processing still need to be connected and tested.", color = Muted, style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

private fun queryDisplayName(context: Context, uri: Uri): String {
    var name = "Selected image"
    context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
        if (cursor.moveToFirst()) name = cursor.getString(0) ?: name
    }
    return name
}


private fun fetchPublicMarketAnalysis(symbol: String, interval: String): String {
    val endpoint = "https://data-api.binance.vision/api/v3/klines?symbol=$symbol&interval=$interval&limit=100"
    val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
        requestMethod = "GET"
        connectTimeout = 12000
        readTimeout = 15000
        setRequestProperty("Accept", "application/json")
    }
    val code = connection.responseCode
    val body = (if (code in 200..299) connection.inputStream else connection.errorStream)
        .bufferedReader().use { it.readText() }
    connection.disconnect()
    if (code !in 200..299) error("HTTP $code from public market-data API")
    val rows = JSONArray(body)
    if (rows.length() < 30) error("Not enough candle data")
    val closes = (0 until rows.length()).map { i ->
        rows.getJSONArray(i).getString(4).toDouble()
    }
    val last = closes.last()
    val previous = closes[closes.size - 2]
    val ema9 = calculateEma(closes, 9)
    val ema21 = calculateEma(closes, 21)
    val rsi = calculateRsi(closes, 14)
    val momentum = ((last - previous) / previous) * 100.0
    val trend = when {
        ema9 > ema21 && last > ema9 -> "Bullish bias (UP)"
        ema9 < ema21 && last < ema9 -> "Bearish bias (DOWN)"
        else -> "Mixed / NO TRADE"
    }
    val caution = when {
        rsi >= 70 -> "RSI is overbought; upward continuation may be vulnerable."
        rsi <= 30 -> "RSI is oversold; downward continuation may be vulnerable."
        else -> "RSI is not at an extreme level."
    }
    return buildString {
        appendLine("LIVE PUBLIC MARKET DATA — $symbol • $interval")
        appendLine("Last closed/latest candle close: ${"%.6f".format(java.util.Locale.US, last)} USDT")
        appendLine("EMA 9: ${"%.6f".format(java.util.Locale.US, ema9)}")
        appendLine("EMA 21: ${"%.6f".format(java.util.Locale.US, ema21)}")
        appendLine("RSI 14: ${"%.2f".format(java.util.Locale.US, rsi)}")
        appendLine("Previous-candle momentum: ${"%.4f".format(java.util.Locale.US, momentum)}%")
        appendLine("Rule-based bias: $trend")
        appendLine(caution)
        appendLine("Source: Binance public spot market-data endpoint. This is not Quotex data and is not a prediction guarantee.")
    }
}

private fun calculateEma(values: List<Double>, period: Int): Double {
    val k = 2.0 / (period + 1.0)
    var ema = values.take(period).average()
    for (value in values.drop(period)) ema = value * k + ema * (1.0 - k)
    return ema
}

private fun calculateRsi(closes: List<Double>, period: Int): Double {
    val changes = closes.zipWithNext { a, b -> b - a }.takeLast(period)
    val gain = changes.filter { it > 0 }.sum() / period
    val loss = -changes.filter { it < 0 }.sum() / period
    if (loss == 0.0) return 100.0
    val rs = gain / loss
    return 100.0 - (100.0 / (1.0 + rs))
}

private fun callBackend(context: Context, baseUrl: String, uri: Uri): String {
    val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: error("Could not read image")
    val boundary = "----AndroidBoundary${System.currentTimeMillis()}"
    val connection = (URL(baseUrl.trimEnd('/') + "/analyze").openConnection() as HttpURLConnection).apply {
        requestMethod = "POST"; connectTimeout = 15000; readTimeout = 30000; doOutput = true
        setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
    }
    connection.outputStream.use { out ->
        out.write("--$boundary\r\n".toByteArray())
        out.write("Content-Disposition: form-data; name=\"file\"; filename=\"chart.jpg\"\r\n".toByteArray())
        out.write("Content-Type: image/jpeg\r\n\r\n".toByteArray())
        out.write(bytes); out.write("\r\n--$boundary--\r\n".toByteArray())
    }
    val code = connection.responseCode
    val stream = if (code in 200..299) connection.inputStream else connection.errorStream
    val body = stream.bufferedReader().use { it.readText() }
    connection.disconnect()
    if (code !in 200..299) error("HTTP $code: $body")
    return JSONObject(body).optString("analysis", body)
}
